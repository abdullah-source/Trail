import { makeEvent, sha256Hex, nowTs, uuid, GENESIS } from "./chain.js";
import * as db from "./db.js";
import { APP_ORIGIN, ALLOWED_ORIGINS } from "./config.js";

// ---- per-doc chain state (service worker may restart; heads are persisted) ----
const sessions = new Map();   // docId -> {id, seq, head}
let lastCopy = null;          // {host, hash, len, ts, tab}
// Known AI sites. A plain entry matches the host and its subdomains; an entry with a path
// ("huggingface.co/chat") matches only that part of the site, so only a URL can match it and
// the record keeps the `ai` flag because the host alone would not tell.
const AI_HOSTS = ["chatgpt.com", "chat.openai.com", "claude.ai", "gemini.google.com", "bard.google.com", "notebooklm.google.com", "copilot.microsoft.com", "perplexity.ai", "www.perplexity.ai", "poe.com", "character.ai", "you.com", "grok.com", "x.ai", "meta.ai", "mistral.ai", "chat.mistral.ai", "deepseek.com", "chat.deepseek.com", "huggingface.co/chat", "writesonic.com", "jasper.ai", "app.jasper.ai", "quillbot.com", "grammarly.com", "app.grammarly.com", "undetectable.ai", "phrasly.ai", "humanizeai.pro"];

const aiHost = (h) => AI_HOSTS.some((a) => !a.includes("/") && (h === a || h.endsWith("." + a)));
function classify(host, fromSelf) {
  if (fromSelf) return "self";
  if (!host) return "unknown";
  return aiHost(host.toLowerCase()) ? "ai" : "web";
}
function isAiUrl(url) {
  let u; try { u = new URL(url); } catch { return false; }
  const host = u.host.toLowerCase();
  if (aiHost(host)) return true;
  const hp = host + u.pathname.toLowerCase();
  return AI_HOSTS.some((a) => a.includes("/") && (hp === a || hp.startsWith(a + "/")));
}

const words = (text) => text.split(/\s+/).filter(Boolean).length;

// ---- recording consent ------------------------------------------------------------------------------
// Nothing is recorded until the student says so, in the popup or on the web app's welcome page:
// `consent: {v: 1, at}` in chrome.storage.local. Without it the recorder, presence and copy scripts
// stay silent, and here no tab is tracked, no message is stored and no checkpoint is sent.
// Withdrawing it ("Stop recording on this computer") closes the open sessions and stops all of that
// at once; what was recorded before stays on the device until the student deletes it.
const CONSENT_VERSION = 1;
let consentCache = null;       // null until read from storage after a (re)start
async function consented() {
  if (consentCache === null) consentCache = !!(await chrome.storage.local.get("consent")).consent;
  return consentCache;
}
async function consentState() {
  const { consent } = await chrome.storage.local.get("consent");
  return consent ? { granted: true, v: consent.v, at: consent.at } : { granted: false };
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !("consent" in changes)) return;
  consentCache = !!changes.consent.newValue;
  if (!consentCache) { front = null; lastFront = null; lastCopy = null; tabDocs.clear(); }
});
async function setConsent(granted) {
  if (granted) {
    const prev = (await chrome.storage.local.get("consent")).consent;
    const consent = prev && prev.v === CONSENT_VERSION ? prev : { v: CONSENT_VERSION, at: nowTs() };
    await chrome.storage.local.set({ consent });
    consentCache = true;
    return consentState();
  }
  // Withdraw: close every open session (the last event written), then forget the front tab and the
  // last copy. Runs inside the message queue, so no recorder message is half-way through.
  for (const docId of [...sessions.keys()]) await endSession(docId, "stopped", Date.now());
  for (const d of await db.all("docs")) if (d.openSession) await endSession(d.id, "stopped", Date.now()).catch(() => {});
  consentCache = false;
  front = null; lastFront = null; lastCopy = null; tabDocs.clear();
  await chrome.storage.local.remove("consent");
  return { granted: false };
}

// ---- paste sources on every site (optional) ----------------------------------------------------------
// By default copytrack.js runs only on the supported editor and LMS sites (manifest content_scripts).
// When the student turns on "Know where pastes come from" in the popup, Chrome grants the optional
// host permissions below and copytrack.js is registered for every site; when the permission is
// removed (popup toggle or chrome://extensions) it is unregistered. Without it a paste copied from
// another site has source_kind "unknown".
const ALL_SITES = ["https://*/*", "http://*/*"];
const COPYTRACK_ID = "trail-copytrack";
async function syncCopytrack() {
  const granted = await chrome.permissions.contains({ origins: ALL_SITES });
  const registered = (await chrome.scripting.getRegisteredContentScripts({ ids: [COPYTRACK_ID] })).length > 0;
  if (granted && !registered) {
    const editors = (chrome.runtime.getManifest().content_scripts || [])[0]?.matches || [];
    await chrome.scripting.registerContentScripts([{ id: COPYTRACK_ID, matches: ALL_SITES, excludeMatches: editors, js: ["src/copytrack.js"], runAt: "document_start", allFrames: true, persistAcrossSessions: true }]);
  } else if (!granted && registered) {
    await chrome.scripting.unregisterContentScripts({ ids: [COPYTRACK_ID] });
  }
  return { granted, registered: granted };
}
let copytrackSync = Promise.resolve();
const resyncCopytrack = () => (copytrackSync = copytrackSync.then(syncCopytrack, syncCopytrack).catch((e) => ({ error: String(e) })));
chrome.permissions.onAdded.addListener(resyncCopytrack);
chrome.permissions.onRemoved.addListener(resyncCopytrack);
chrome.runtime.onStartup.addListener(resyncCopytrack);
resyncCopytrack();

// ---- document ids: the editor's id (gdoc:..., notion:..., page:host/path) never leaves this device.
// Every document gets a random id, minted once and stored locally; events, checkpoints and the
// web app all use that id. The server only ever sees random ids.
const aliases = new Map();   // editorId -> random id
async function resolveDoc(editorId, editor, host) {
  if (!editorId) return editorId;
  if (aliases.has(editorId)) return aliases.get(editorId);
  let doc = (await db.byIndex("docs", "editorId", editorId))[0];
  if (!doc) {
    doc = { id: "tr_" + uuid().replace(/-/g, ""), editorId, editor, host, title: null, created: nowTs(), events: 0, typed: 0, pasted: 0, deleted: 0, words: 0 };
    await db.put("docs", doc);
  }
  aliases.set(editorId, doc.id);
  return doc.id;
}

async function pausedHosts() {
  return new Set((await chrome.storage.local.get("paused")).paused || []);
}

async function loadSession(docId) {
  if (sessions.has(docId)) return sessions.get(docId);
  const d = await db.get("docs", docId);
  if (d && d.openSession) {
    const s = await db.get("sessions", d.openSession);
    if (s && !s.ended) { sessions.set(docId, { id: s.id, seq: s.seq, head: s.head }); return sessions.get(docId); }
  }
  return null;
}

async function startSession(docId, editor, host, data, ts) {
  const id = uuid();
  const s = { id, seq: 0, head: GENESIS };
  sessions.set(docId, s);
  await db.put("sessions", { id, doc: docId, editor, host, started: nowTs(new Date(ts)), seq: 0, head: GENESIS, ended: false });
  const doc = (await db.get("docs", docId)) || { id: docId, editor, host, title: null, created: nowTs(), events: 0, typed: 0, pasted: 0, deleted: 0, words: 0 };
  doc.openSession = id; doc.lastSeen = nowTs();
  await db.put("docs", doc);
  await append(docId, "session.start", data, ts);
  return s;
}

async function append(docId, kind, data, tsMs) {
  const s = sessions.get(docId);
  if (!s) return null;
  const ev = await makeEvent({ session: s.id, doc: docId, seq: s.seq, kind, data, prev: s.head, ts: nowTs(new Date(tsMs || Date.now())) });
  s.seq += 1; s.head = ev.hash;
  await db.put("events", ev);
  const sess = await db.get("sessions", s.id);
  if (sess) { sess.seq = s.seq; sess.head = s.head; sess.first_ts = sess.first_ts || ev.ts; sess.last = ev.ts; await db.put("sessions", sess); }
  const doc = await db.get("docs", docId);
  if (doc) {
    doc.events = (doc.events || 0) + 1; doc.lastSeen = ev.ts; doc.firstSeen = doc.firstSeen || ev.ts;
    if (kind === "insert") doc.typed = (doc.typed || 0) + data.text.length;
    if (kind === "paste") doc.pasted = (doc.pasted || 0) + data.text.length;
    if (kind === "delete") doc.deleted = (doc.deleted || 0) + data.len;
    if (kind === "snapshot") doc.words = data.words;
    doc.dirty = true;
    await db.put("docs", doc);
  }
  return ev;
}

async function endSession(docId, reason, tsMs) {
  const s = sessions.get(docId) || (await loadSession(docId));
  if (!s) return;
  sessions.set(docId, s);
  await append(docId, "session.end", { reason }, tsMs);
  const sess = await db.get("sessions", s.id);
  if (sess) { sess.ended = true; await db.put("sessions", sess); }
  const doc = await db.get("docs", docId);
  if (doc) { doc.openSession = null; await db.put("docs", doc); }
  sessions.delete(docId);
}

// ---- work log: screen time for homework ------------------------------------------------------------
// presence.js sends {type:"presence", active_ms, ts, course_key, item_key, ...} every 30 s of active
// time. One row is one continuous stint: heartbeats within 10 minutes of the row's end for the same
// item extend it; otherwise a new row starts. Writing time stays derived from sessions in the web
// app; these rows carry the document's random id so the two can be merged there, never here.
const STINT_GAP_MS = 10 * 60_000;
const localDay = (d) => { const x = new Date(d); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`; };
async function lookupDoc(editorId) {
  if (!editorId) return null;
  if (aliases.has(editorId)) return aliases.get(editorId);
  const doc = (await db.byIndex("docs", "editorId", editorId))[0];
  if (doc) aliases.set(editorId, doc.id);
  return doc ? doc.id : null;
}
async function latestStint(itemKey) {
  const rows = await db.byIndex("worklog", "item_key", itemKey);
  return rows.sort((a, b) => (a.end < b.end ? 1 : a.end > b.end ? -1 : 0))[0] || null;
}
async function notePresence(m) {
  const active = Number(m.active_ms) || 0;
  if (!m.course_key || !m.item_key || active <= 0 || active > 6 * 3_600_000) return null;
  const tsMs = Number(m.ts) || Date.now();
  const startMs = tsMs - active;
  const doc = await lookupDoc(m.editor_doc);
  // Writing pages: the editor's own id is only a placeholder until the recorder has minted the random id.
  const itemKey = doc || m.item_key;
  let row = await latestStint(itemKey);
  if (!row && doc && m.item_key !== doc) {
    // earlier stints on this document were filed before its random id existed: adopt them
    for (const old of await db.byIndex("worklog", "item_key", m.item_key)) { old.item_key = doc; old.doc = doc; await db.put("worklog", old); }
    row = await latestStint(itemKey);
  }
  if (row && startMs - Date.parse(row.end) <= STINT_GAP_MS) {
    row.end = nowTs(new Date(Math.max(tsMs, Date.parse(row.end))));
    row.active_ms += active;
    row.heartbeats += 1;
    if (m.item_label) row.item_label = m.item_label;
    if (m.course_label) row.course_label = m.course_label;
    if (doc && !row.doc) row.doc = doc;
    await db.put("worklog", row);
    return row.id;
  }
  row = { id: "wl_" + uuid().replace(/-/g, ""), host: m.host || null, editor: m.editor || null, kind: m.kind || "other", course_key: m.course_key, course_label: m.course_label || null,
          item_key: itemKey, item_label: m.item_label || null, doc, start: nowTs(new Date(startMs)), end: nowTs(new Date(tsMs)), active_ms: active, day: localDay(startMs), heartbeats: 1 };
  await db.put("worklog", row);
  return row.id;
}
async function worklogRows(since, until) {
  const rows = await db.all("worklog");
  const out = rows.filter((r) => (!since || r.start >= since) && (!until || r.start < until));
  return out.sort((a, b) => (a.start < b.start ? -1 : a.start > b.start ? 1 : 0));
}
async function worklogToday(itemKey, editorDoc) {
  const doc = await lookupDoc(editorDoc);
  const keys = new Set([itemKey, doc].filter(Boolean));
  const today = localDay(Date.now());
  let ms = 0;
  for (const k of keys) for (const r of await db.byIndex("worklog", "item_key", k)) if (r.day === today) ms += r.active_ms;
  return { active_ms: ms, doc };
}
async function worklogSummary(since, until) {
  const rows = await worklogRows(since, until);
  const courses = new Map(), items = new Map(), days = new Map(), hours = new Array(24).fill(0);
  let total = 0;
  for (const r of rows) {
    total += r.active_ms;
    const c = courses.get(r.course_key) || { course_key: r.course_key, course_label: r.course_label, active_ms: 0, _items: new Set() };
    c.active_ms += r.active_ms; c._items.add(r.item_key); if (r.course_label) c.course_label = r.course_label; courses.set(r.course_key, c);
    const it = items.get(r.item_key) || { item_key: r.item_key, item_label: r.item_label, course_key: r.course_key, course_label: r.course_label, kind: r.kind, active_ms: 0, stints: 0, last: r.end, doc: r.doc || null };
    it.active_ms += r.active_ms; it.stints += 1; if (r.end > it.last) it.last = r.end; if (r.item_label) it.item_label = r.item_label; if (r.course_label) it.course_label = r.course_label; if (r.doc) it.doc = r.doc; items.set(r.item_key, it);
    days.set(r.day, (days.get(r.day) || 0) + r.active_ms);
    // spread the stint's active time over the clock hours it spans, in proportion to wall time
    const s = Date.parse(r.start), e = Math.max(Date.parse(r.end), s + 1), span = e - s;
    let t = s;
    while (t < e) {
      const d = new Date(t); const hourEnd = new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours() + 1).getTime();
      const slice = Math.min(e, hourEnd) - t;
      hours[d.getHours()] += Math.round((slice / span) * r.active_ms);
      t = hourEnd;
    }
  }
  return {
    total_ms: total,
    by_course: [...courses.values()].map(({ _items, ...c }) => ({ ...c, items: _items.size })).sort((a, b) => b.active_ms - a.active_ms),
    by_item: [...items.values()].sort((a, b) => b.active_ms - a.active_ms),
    by_day: [...days.entries()].map(([day, active_ms]) => ({ day, active_ms })).sort((a, b) => (a.day < b.day ? -1 : 1)),
    by_hour: hours,
  };
}

// ---- messages from content scripts and the popup ------------------------------------------------
// Messages from one page arrive in order but were handled concurrently, so a session.start
// and the first event could race and mint two sessions (or two doc ids). Handle them one at a time.
let queue = Promise.resolve();
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  const job = async () => {
    if (m.type === "consent.get") return consentState();
    if (m.type === "consent.set") return setConsent(!!m.granted);
    if (m.type === "copytrack.sync") return resyncCopytrack();
    if (m.type === "status.bg") { const { token } = await chrome.storage.local.get("token"); return { connected: !!token, paused: [...(await pausedHosts())], consent: await consented() }; }
    if (m.type === "checkpointAll") return checkpointAll();
    if (m.type === "pause") {
      const p = await pausedHosts();
      if (m.paused) p.add(m.host); else p.delete(m.host);
      await chrome.storage.local.set({ paused: [...p] });
      return { paused: [...p] };
    }
    if (!(await consented())) return;   // no consent: nothing below is stored or acted on
    if (m.type === "copy") { lastCopy = { host: m.host, hash: m.hash, len: m.len, ts: m.ts, tab: sender.tab && sender.tab.id }; return; }
    if (m.type === "presence.today") return worklogToday(m.item_key, m.editor_doc);
    if (m.host && (await pausedHosts()).has(m.host)) return;  // per-site pause: nothing is recorded
    if (m.type === "presence") return notePresence(m);
    m.doc = await resolveDoc(m.doc, m.editor, m.host);
    if (sender.tab && m.doc) tabDocs.set(sender.tab.id, m.doc);
    if (m.type === "session.start") { await endSession(m.doc, "restart", Date.now()); await startSession(m.doc, m.editor, m.host, m.data, Date.now()); return; }
    if (m.type === "session.end") { await endSession(m.doc, m.reason || "completed", Date.now()); return; }
    if (!sessions.has(m.doc)) { const s = await loadSession(m.doc); if (!s) await startSession(m.doc, m.editor, m.host, { editor: m.editor, host: m.host, title_hash: null, goal_words: null, goal_minutes: null }, m.ts || Date.now()); }
    if (m.type === "event") { await append(m.doc, m.kind, m.data, m.ts); return; }
    if (m.type === "paste") {
      const h = await sha256Hex(m.data.text);
      const fromSelf = !!(lastCopy && lastCopy.hash === h && sender.tab && lastCopy.tab === sender.tab.id);
      const srcHost = lastCopy && lastCopy.hash === h ? lastCopy.host : null;
      await append(m.doc, "paste", { paste_id: uuid(), pos: m.data.pos, text: m.data.text, source_host: srcHost, source_kind: classify(srcHost, fromSelf), from_self: fromSelf }, m.ts);
      return;
    }
    if (m.type === "snapshot") {
      const text = m.text || "";
      const hash = await sha256Hex(text);
      await append(m.doc, "snapshot", { text_hash: hash, chars: text.length, words: words(text), lines: text.split("\n").length }, m.ts);
      await db.put("snapshots", { doc: m.doc, ts: nowTs(new Date(m.ts)), text });
      if (m.title) { const doc = await db.get("docs", m.doc); if (doc && doc.title !== m.title) { doc.title = m.title; await db.put("docs", doc); } }
      return;
    }
    if (m.type === "ai.note") { await append(m.doc, "ai.note", { tool: m.tool, note: m.note }, Date.now()); return; }
  };
  queue = queue.then(job, job).then((result) => reply && reply({ ok: true, result }), (e) => reply && reply({ ok: false, error: String(e) }));
  return true;
});

// ---- messages from the web app (externally_connectable) ------------------------------------------
// Events never leave this device except through this channel to the Trail page itself.
function originOf(sender) {
  if (sender.origin) return sender.origin;
  try { return new URL(sender.url).origin; } catch { return null; }
}

async function listDocs() {
  const docs = await db.all("docs");
  const out = [];
  for (const d of docs) {
    const sess = await db.byIndex("sessions", "doc", d.id);
    out.push({ id: d.id, title: d.title || null, editor: d.editor || "generic", firstSeen: d.firstSeen || d.created, lastSeen: d.lastSeen || d.created,
               typed: d.typed || 0, pasted: d.pasted || 0, deleted: d.deleted || 0, events: d.events || 0, sessions: sess.length, words: d.words || 0 });
  }
  return out;
}

async function getEvents(docId) {
  const evs = await db.byIndex("events", "doc", docId);
  return evs.sort((a, b) => (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : a.seq - b.seq));
}

async function getCheckpoints(docId) {
  return (await db.byIndex("checkpoints", "doc", docId)).sort((a, b) => a.seq - b.seq).map((c) => ({ body: c.body, signature: c.signature, key_id: c.key_id, hash: c.hash }));
}

async function addAiNote(docId, tool, note) {
  if (!sessions.has(docId) && !(await loadSession(docId))) {
    const doc = await db.get("docs", docId);
    if (!doc) throw new Error("unknown document");
    await startSession(docId, doc.editor, doc.host, { editor: doc.editor, host: doc.host, title_hash: null, goal_words: null, goal_minutes: null }, Date.now());
  }
  await append(docId, "ai.note", { tool, note }, Date.now());
}

chrome.runtime.onMessageExternal.addListener((m, sender, reply) => {
  const origin = originOf(sender);
  if (!ALLOWED_ORIGINS.includes(origin)) { reply({ ok: false, error: `origin ${origin} is not allowed` }); return false; }
  (async () => {
    switch (m && m.type) {
      case "status": {
        const { token } = await chrome.storage.local.get("token");
        return { version: chrome.runtime.getManifest().version, connected: !!token, recording: sessions.size > 0, consent: await consented() };
      }
      // recording consent, given or withdrawn from the web app's welcome page (same rules as the popup)
      case "getConsent": return consentState();
      case "setConsent": return serial(() => setConsent(m.granted === true));
      case "listDocs": case "getEssays": return listDocs();
      case "getEvents": return getEvents(m.doc);
      case "getCheckpoints": return getCheckpoints(m.doc);
      case "setToken": {
        if (m.token) await chrome.storage.local.set({ token: m.token, server: (m.server || origin).replace(/\/$/, "") });
        else await chrome.storage.local.remove(["token", "server"]);
        return { connected: !!m.token };
      }
      case "addAiNote":
        if (!(await consented())) throw new Error("Recording is off on this computer: start it from the Trail button in the toolbar.");
        await serial(() => addAiNote(m.doc, m.tool, m.note)); return null;
      case "checkpoint": {
        const r = await checkpointAll(m.doc);
        const row = Array.isArray(r) ? r.find((x) => x.doc === m.doc) : null;
        if (r && r.skipped === "no consent") throw new Error("Recording is off on this computer: start it from the Trail button in the toolbar.");
        if (r && r.skipped) throw new Error("Not connected: open Settings and connect the extension first.");
        if (row && row.error) throw new Error(row.error);
        return { created: !!(row && row.created) };
      }
      case "clearAll": await serial(async () => { await db.clearAll(); sessions.clear(); aliases.clear(); tabDocs.clear(); }); return null;
      // work log (screen time for homework): local only, read here like essays are
      case "listWorklog": return worklogRows(m.since || null, m.until || null);
      case "worklogSummary": return worklogSummary(m.since || null, m.until || null);
      case "exportWorklog": return worklogRows(null, null);
      case "deleteWorklog": await db.clear("worklog"); return null;
      default: throw new Error(`unknown message type ${m && m.type}`);
    }
  })().then((result) => reply({ ok: true, result })).catch((e) => reply({ ok: false, error: e && e.message ? e.message : String(e) }));
  return true;
});

// ---- first run: open the welcome page -------------------------------------------------------------
// The welcome page asks for recording consent first (bridge `setConsent`); so does the popup.
chrome.runtime.onInstalled.addListener((d) => {
  if (d.reason === "install") chrome.tabs.create({ url: `${APP_ORIGIN}/app/welcome` });
  resyncCopytrack();
});

// ---- source visits and returns: which tab is in front while a document session is open ----------
// The tab in front of the focused Chrome window is tracked across tab switches, window switches and
// in-tab navigation. When it leaves the front, its dwell is recorded for every open session as
// `source.visit {host, dwell_ms, ai?}`: host only, never the URL or title; `ai: true` when the page was
// a known AI site. Dwell counts only while a Chrome window has the focus. When a tab holding a recorded
// document comes back in front from another tab, `focus {state: "focus", from_host, from_ai}` is
// recorded for that document, so the analysis can show what was typed right after a return. These are
// facts about tabs and timing; nothing here decides what they mean.
const MIN_DWELL_MS = 5000;
let front = null;              // {tabId, windowId, host, ai, docId|null}: the tab in front of a focused window
let frontSince = 0;
let lastFront = null;          // the tab that was in front before `front` (kept while no window has focus)
let focusedWindow = null;      // window id with the OS focus; null until Chrome tells us
const tabDocs = new Map();     // tabId -> random doc id of the document recorded in that tab

// Tab changes are serialised with the recorder's messages: `append` must never run twice at once.
function serial(job) { const p = queue.then(job, job); queue = p.catch(() => {}); return p; }
const hostOf = (url) => { try { return new URL(url).host || null; } catch { return null; } };

async function docOfTab(tabId) {
  if (tabDocs.has(tabId)) return tabDocs.get(tabId);
  // Ask the recorder in that tab which document it holds; pages without a recorder do not answer.
  let st = null;
  try {
    st = await Promise.race([chrome.tabs.sendMessage(tabId, { type: "status" }), new Promise((r) => setTimeout(() => r(null), 1500))]);
  } catch { return null; }
  const doc = st && st.doc ? await lookupDoc(st.doc) : null;
  if (doc) tabDocs.set(tabId, doc);
  return doc;
}

async function closeFront(now) {
  if (!front) return;
  if (!(await consented())) { front = null; return; }
  const dwell = now - frontSince;
  if (front.host && dwell >= MIN_DWELL_MS) {
    const data = { host: front.host, dwell_ms: dwell };
    if (front.ai) data.ai = true;
    for (const [docId] of sessions) await append(docId, "source.visit", data, now);
  }
  lastFront = front;
  front = null;
}

async function setFront(tab, now) {
  if (!(await consented())) { front = null; lastFront = null; return; }   // no consent: no tab is tracked
  const url = (tab && tab.url) || "";
  const host = hostOf(url);
  const ai = isAiUrl(url);
  if (front && tab && front.tabId === tab.id && front.host === host && front.ai === ai) return;  // same page, same tab
  await closeFront(now);
  if (!tab) return;
  front = { tabId: tab.id, windowId: tab.windowId, host, ai, docId: null };
  frontSince = now;
  const from = lastFront;
  const doc = await docOfTab(tab.id);
  if (!doc || !front || front.tabId !== tab.id) return;
  front.docId = doc;
  // A recorded document came back in front from another tab: note where from (host only).
  if (from && from.tabId !== tab.id && (sessions.has(doc) || (await loadSession(doc)))) {
    await append(doc, "focus", { state: "focus", from_host: from.host, from_ai: !!from.ai }, now);
  }
}

chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
  const now = Date.now();
  serial(async () => {
    if (focusedWindow !== null && focusedWindow !== windowId) return;   // a tab changed in a window that is not in front
    let tab = null; try { tab = await chrome.tabs.get(tabId); } catch {}
    await setFront(tab, now);
  });
});
chrome.windows.onFocusChanged.addListener((windowId) => {
  const now = Date.now();
  serial(async () => {
    if (windowId === chrome.windows.WINDOW_ID_NONE) { focusedWindow = windowId; await closeFront(now); return; }
    focusedWindow = windowId;
    let tab = null; try { [tab] = await chrome.tabs.query({ active: true, windowId }); } catch {}
    await setFront(tab || null, now);
  });
});
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (!info.url) return;
  const now = Date.now();
  serial(async () => {
    tabDocs.delete(tabId);                                        // the tab may now hold another document, or none
    if (front && front.tabId === tabId) await setFront(tab, now);  // the front tab moved to another page
  });
});
chrome.tabs.onRemoved.addListener((tabId) => { tabDocs.delete(tabId); });
// The worker may have just (re)started: pick up the tab that is in front right now.
serial(async () => {
  try {
    const w = await chrome.windows.getLastFocused();
    if (!w || !w.focused) return;
    focusedWindow = w.id;
    const [tab] = await chrome.tabs.query({ active: true, windowId: w.id });
    if (tab) await setFront(tab, Date.now());
  } catch {}
});

// ---- checkpoints: every 10 minutes, send chain heads (never text) to the signing service ----
chrome.alarms.create("checkpoint", { periodInMinutes: 10 });
chrome.alarms.onAlarm.addListener(async (a) => { if (a.name === "checkpoint") await checkpointAll(); });

export async function checkpointAll(onlyDoc) {
  if (!(await consented())) return { skipped: "no consent" };
  const { server, token } = await chrome.storage.local.get(["server", "token"]);
  if (!server || !token) return { skipped: "not signed in" };
  const docs = await db.all("docs");
  const out = [];
  for (const doc of docs) {
    if (onlyDoc ? doc.id !== onlyDoc : !doc.dirty) continue;
    const sess = await db.byIndex("sessions", "doc", doc.id);
    const heads = {};
    for (const s of sess) if (s.seq > 0) heads[s.id] = { seq: s.seq - 1, hash: s.head, first_ts: s.first_ts || s.started };
    if (!Object.keys(heads).length) continue;
    try {
      // chain heads and the random document id only: no title, no editor id, no text
      const r = await fetch(server + "/v1/checkpoint", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + token }, body: JSON.stringify({ doc: doc.id, heads }) });
      if (r.status === 401) { await chrome.storage.local.remove(["token"]); out.push({ doc: doc.id, error: "Signed out: reconnect the extension from Settings." }); continue; }
      const j = await r.json();
      if (!r.ok) { out.push({ doc: doc.id, error: typeof j.detail === "string" ? j.detail : `HTTP ${r.status}` }); continue; }
      if (j.created && j.checkpoint) { await db.put("checkpoints", { doc: doc.id, seq: j.checkpoint.body.seq, ...j.checkpoint }); }
      doc.dirty = false; doc.lastCheckpoint = nowTs(); await db.put("docs", doc);
      out.push({ doc: doc.id, created: !!j.created });
    } catch (e) { out.push({ doc: doc.id, error: String(e) }); }
  }
  return out;
}

// test hook: test/presence-harness.mjs calls these inside the worker (dynamic import() is not allowed there)
globalThis.__trailTest = { worklogSummary, worklogRows, clearWorklog: () => db.clear("worklog"), isAiUrl, classify, front: () => front,
  setConsent: (granted) => serial(() => setConsent(granted)), consentState, checkpointAll, syncCopytrack, lastCopy: () => lastCopy,
  registered: () => chrome.scripting.getRegisteredContentScripts() };
